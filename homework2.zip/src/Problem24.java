//24. Write a Java program to find the penultimate (next to last) word of a sentence.
//Sample Output:
//
//Input a String: The quick brown fox jumps over the lazy dog.
//Penultimate word: lazy

import java.util.Scanner;

public class Problem24 {
    public static void main(String[] args) {

        Scanner in=new Scanner(System.in);
        String string = "";
        String[] splitedString;

        System.out.print("Input a Sentence: ");
        string = in.nextLine();

        splitedString = string.split(" ");

        System.out.println("Penultimate word: " + splitedString[splitedString.length-2]);;

    }
}
