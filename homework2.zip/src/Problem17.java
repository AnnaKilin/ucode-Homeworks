//17. Write a Java program to find the size of a specified file.
//Sample Output:
//
///home/students/abc.txt  : 0 bytes
///home/students/test.txt : 0 bytes

import  java.io.File;




public class Problem17 {
    public static void main(String[] args) {

        String pathFile = "E:\\vcredist.bmp";

        File file = new File(pathFile);
        if(file.exists()){
            System.out.println(file.getAbsolutePath()+ " : " + file.length());
        }
    }
}




