//38. Write a Java method to count all vowels in a string.
//Test Data:
//Input the string: w3resource
//Expected Output:
//
//Number of  Vowels in the string: 4


import java.util.Scanner;



public class Problem38 {
    public static void main(String[] args) {

        String str="";
        int count=0;
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter a string:");
        str=sc.nextLine();

        for(int i=0;i<str.length();++i)
        {
            switch(str.charAt(i))
            {
                case 'a':
                case 'A':
                case 'e':
                case 'E':
                case 'i':
                case 'I':
                case 'o':
                case 'O':
                case 'u':
                case 'U': count++;
            }
        }

        System.out.println("Number of vowels are "+count);

        }
}
