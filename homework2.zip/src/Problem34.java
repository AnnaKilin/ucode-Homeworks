//34. Write a Java program to rearrange all the elements of an given array of
// integers so that all the odd numbers come before all the even numbers


import java.util.Arrays;

public class Problem34 {
    public static void main(String[] args) {

        int[] arr = {1, 2156, 1, 546, 546, 1, 6, 87, 546, 13, 684, 879, 54, 6, 5, 5, 8, 9, 4, 3, 6, 8, 9};
        int[] arrOdd = new int[arr.length];
        int[] arrEven = new int[arr.length];
        System.out.println("Original Array is: " + Arrays.toString(arr));
        int odd = 0, even = 0;
        for(int i: arr){
            if(i%2!=0){
                arrOdd[odd] = i;
                odd++;
            }else{
                arrEven[even] = i;
                even++;
            }
        }
        for(int i = 0 ; i < arr.length ; i++){
            if(i < odd){
                arr[i] = arrOdd[i];
            } else {
                arr[i] = arrEven[i-odd];
            }
        }
        System.out.println("The new array is: " + Arrays.toString(arr));
    }
}
