//2. Write a Java program to reverse a string.
//Input Data:
//Input a string: The quick brown fox
//Expected Output
//
//Reverse string: xof nworb kciuq ehT


import java.util.Scanner;

public class Problem12 {
    public static void main(String[] args) {

    Scanner in= new Scanner(System.in);
    String []s=in.nextLine().split(" ");

    for (int i= s.length-1; i>=0; i--){

        char [] reversWord = s[i].toCharArray();
        char [] reversedWords = new char[reversWord.length];
        int k=0;
        for(int j = reversWord.length-1; j>=0; j--) {
            reversedWords[k] = reversWord[j];
            k++;
        }
        s[i] = String.valueOf(reversedWords);

        System.out.print(s[i] + " ");
    }

    }
}
