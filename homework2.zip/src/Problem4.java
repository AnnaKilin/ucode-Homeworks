//4. Write a Java program to print the area and perimeter of a circle.
//Test Data:
//Radius = 7.5


import java.util.Scanner;

public class Problem4 {
    public static void main(String[] args) {

        Scanner sc=new Scanner(System.in);
        int radius=0;
        double pi=3.14;
        System.out.print("Enter the radius:");
        radius = sc.nextInt();
        System.out.print("Perimeter of circle is:");
        System.out.print(pi*2*radius);

        System.out.print("\n Area of circle is:");
        System.out.print(pi*radius*radius);
    }
}
