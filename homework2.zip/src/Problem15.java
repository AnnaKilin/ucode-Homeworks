//15. Write a Java program to print the ascii value of a given character.
//Expected Output
//
//The ASCII value of Z is :90


import java.util.Scanner;

public class Problem15 {
    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);
        System.out.println("Enter a character");
        char c = scan.nextLine().charAt(0);
        int i = c;
        System.out.println("The ASCII value of '"+c+"' = " +i);

    }
}
