//22. Write a Java program to capitalize the first letter of each word in a sentence.
//Sample Output:
//
//Input a Sentence: the quick brown fox jumps over the lazy dog.
//The Quick Brown Fox Jumps Over The Lazy Dog.




public class Problem22 {
    public static void main(String[] args) {
        String sentence = "the quick brown fox jumps over the lazy dog.";

        String[] words = sentence.split(" ");
        String capitalized = "";

        for (int i = 0; i < words.length; i++) {
            //capitalize o letters in the sentence
            char[] capitalize = words[i].toCharArray();

            for (int j = 0; j < capitalize.length; j++) {
                if (capitalize[j] == 'o')
                    capitalize[j] = 'O';
            }

            words[i] = String.valueOf(capitalize);
            System.out.print(words[i].substring(0, 1).toUpperCase() + words[i].substring(1) + " ");

        }
    }
}
