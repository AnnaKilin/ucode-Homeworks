//7. Write a Java program to swap two integer variables.


import java.util.Scanner;

public class Problem7 {
    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);
        int a, b, temp;
        a = input.nextInt();
        b = input.nextInt();

        System.out.println("Before swap: " + a + ", " + b);
        temp = a;
        a = b;
        b = temp;
        System.out.println("After swapping : " + a + ", " + b);
    }
}
