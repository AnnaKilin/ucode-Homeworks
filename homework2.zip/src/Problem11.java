//11. Write a Java program to compute the distance between two points on the surface of earth.
//Distance between the two points [ (x1,y1) & (x2,y2)]
//d = radius * arccos(sin(x1) * sin(x2) + cos(x1) * cos(x2) * cos(y1 - y2))
//Radius of the earth r = 6371.01 Kilometers
//Input Data:
//
//
//The distance between those points is: 1480.0848451069087 km

import java.util.*;
import java.lang.*;

public class Problem11 {
// Java program to calculate Distance Between
// Two Points on Earth

    public static double distance(double lat1, double lat2, double lon1, double lon2) {
        lon1 = Math.toRadians(lon1);
        lon2 = Math.toRadians(lon2);
        lat1 = Math.toRadians(lat1);
        lat2 = Math.toRadians(lat2);

        // Haversine formula
        double dlon = lon2 - lon1;
        double dlat = lat2 - lat1;
        double a = Math.pow(Math.sin(dlat / 2), 2)
                + Math.cos(lat1) * Math.cos(lat2)
                * Math.pow(Math.sin(dlon / 2), 2);

        double c = 2 * Math.asin(Math.sqrt(a));


        double r = 6371;

        // calculate the result
        return (c * r);
    }

    public static void main(String[] args) {
        double lat1 = 25;
        double lat2 = 35.5;
        double lon1 = 35;
        double lon2 = 25.5;
        System.out.println(distance(lat1, lat2,
                lon1, lon2) + " km");
    }
}
//Input the latitude of coordinate 1: 25
//Input the longitude of coordinate 1: 35
//Input the latitude of coordinate 2: 35.5
//Input the longitude of coordinate 2: 25.5
//Expected Output