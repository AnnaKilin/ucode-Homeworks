//23. Write a Java program to convert a given string into lowercase
// Sample Output:
//Input a String: THE QUICK BROWN FOX JUMPS OVER THE LAZY DOG.
//he quick brown fox jumps over the lazy dog.



import java.util.Scanner;

public class Problem23 {
    public static void main(String[] args) {

        Scanner in=new Scanner(System.in);
        System.out.println("Input a string");

        String line= in.nextLine();
        line=line.toLowerCase();
        System.out.println(line);


    }
}
