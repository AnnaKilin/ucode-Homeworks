//32. Write a Java program to rotate an array (length 3) of integers in left direction.
//Sample Output:
//
//Original Array: [20, 30, 40]
//Rotated Array: [30, 40, 20]


import java.util.Scanner;
import java.util.Arrays;

public class Problem32 {
    public static void main(String[] args) {

        Scanner in = new Scanner(System.in);

        int[] array = new int[3];

        for(int i = 0; i < 3; i++){
            System.out.println("Input number");
            array[i] = in.nextInt();
        }

        System.out.println(Arrays.toString(array));

        int a = array[0];
        int b = array[1];
        int c = array[2];

        array[0] = c;
        array[1] = a;
        array[2] = b;

        System.out.println(Arrays.toString(array));
    }
}
