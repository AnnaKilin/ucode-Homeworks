//10. Write a Java program to compute the area of a hexagon.
//Area of a hexagon = (6 * s^2)/(4*tan(π/6))
//where s is the length of a side
//Input Data:
//Input the length of a side of the hexagon: 6
//Expected Output
//
//The area of the hexagon is: 93.53074360871938

import java.util.Scanner;

public class Problem10 {
    public static void main(String[] args) {
     Scanner in=new Scanner(System.in);
        int side = 0;
        double hexagonArea = 0;

        System.out.print("Input the length of a side of the hexagon: ");
        side = in.nextInt();

        hexagonArea = (6 * Math.pow(side, 2)) / (4 * Math.tan(Math.PI/6));

        System.out.println("\nThe area of the hexagon is: " + hexagonArea);
    }
}
