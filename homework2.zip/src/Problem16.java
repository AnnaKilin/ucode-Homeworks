//16. Write a Java program that accepts an integer (n) and computes the value of n+nn+nnn.
//Sample Output:
//
//Input number: 5
//5 + 55  + 555


import java.util.Scanner;

public class Problem16 {
    public static void main(String[] args) {

        int n;
        Scanner in = new Scanner(System.in);
        System.out.print("Enter an integer: ");
        n = in .nextInt();
        System.out.printf(n+"+"+n+n+"+"+n+n+n);

    }
}
