//9. Write a Java program to display the current date time in specific format.
//Sample Output:
//
//Now: 2017/06/16 08:52:03.066

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Problem19 {
    public static void main(String[] args) {

        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/mm/dd hh:mm:ss");
        LocalDateTime now = LocalDateTime.now();
        System.out.println(dtf.format(now));




    }
}
