//37. Write a Java program to add 3 hours to the current time.


import java.util.Calendar;



public class Problem37{
    public static void main(String[] args) {

        Calendar now = Calendar.getInstance();
        System.out.println("Current time : " + now.get(Calendar.HOUR_OF_DAY)
                + ":"
                + now.get(Calendar.MINUTE)
                + ":"
                + now.get(Calendar.SECOND));
        now.add(Calendar.HOUR,3);
        System.out.println("New time after adding 3 hours : "
                + now.get(Calendar.HOUR_OF_DAY)
                + ":"
                + now.get(Calendar.MINUTE)
                + ":"
                + now.get(Calendar.SECOND));





    }
}