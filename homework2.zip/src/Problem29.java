//28. Write a Java program to insert a word in the middle of the another string (of two words separated by space).
//Insert "Tutorial" in the middle of "Python 3.0", so result will be Python Tutorial 3.0
//Sample Output:
//
//Python Tutorial 3.0


import java.util.Scanner;

public class Problem29 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter a Sentence: ");
        String str = input.nextLine();

        System.out.print("Enter a word that you want insert in the middle of sentence above: ");
        String insert = input.nextLine();

        input.close();

        String[] words = str.split(" ");
        int size = words.length;
        int sizetemp = size + 1;
        String[] output = new String[sizetemp];

        for(int i = 0; i < size; i++){
            output[i] = words[i];
        }

        for(int i = size; i >=size/2; i--)
            if(i!=size/2)
                output[i] = output[i-1];
            else output[i] = insert;

        System.out.print("Result: ");
        for(int i = 0; i <= size; i++)
            System.out.print(output[i] + " ");
    }
}
