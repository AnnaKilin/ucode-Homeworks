//27. Write a Java program that accepts two integer values between 25 to 75 and return true if there is a common digit in both numbers.
//Sample Output:
//
//Input the first number : 35
//Input the second number: 45
//Result: true

import java.util.Scanner;

public class Problem27 {
    public static void main(String[] args) {

            Scanner sc = new Scanner(System.in);
            System.out.println("Input the first number :");
            int a = sc.nextInt();
            System.out.println("Input the second number:");
            int b = sc.nextInt();
            if((a<=75)&&(a>=25)&&(b<=75)&&(b>=25)&&((a%10==b%10)||(a/10==b/10))){
                System.out.println(true);
            }else
                {
                System.out.println(false);
            }
    }
}
