//2. Write a Java program that takes a number as input and prints its multiplication table up to 10.
//
//Input a number: 8
//Expected Output :
//8 x 1 = 8
//8 x 2 = 16
//8 x 3 = 24
//...
//8 x 10 = 80


import java.util.Scanner;

public class Problem2 {
    public static void main(String[] args) {

      Scanner in=new Scanner(System.in);
        System.out.println("Enter a number");
        int number = in.nextInt();
        int i = 1;
        while(i<=10){
            System.out.println(number+" x "+i+" : "+(number*i));
            i++;
        }
    }
}


