//9. Write a Java program to convert a binary number to decimal number.
//Input Data:
//Input a binary number: 100
//Expected Output
//
//Decimal Number: 4


import java.util.Scanner;

public class Problem9 {
    public static void main(String[] args) {
     Scanner in=new Scanner(System.in);
        System.out.println("input the number");
        String bd = in.next();

        int a = Integer.parseInt(bd, 2);

        System.out.println(a);


    }
}
