//18. Write a Java program to display the system time.
//Sample Output:
//
//Current Date time: Fri Jun 16 14:17:40 IST 2017

import java.util.Date;

public class Problem18 {
    public static void main(String[] args) {
        Date d = new Date();
        System.out.println("Current datetime is : "+ d);

    }
}
