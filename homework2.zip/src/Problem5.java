//5. Write a Java program to print the area and perimeter of a rectangle.
//Test Data:
//Width = 5.5 Height = 8.5


import java.util.Scanner;

public class Problem5 {
    public static void main(String[] args) {
        Scanner sc =new Scanner(System.in);
        System.out.println("Insert a: ");
        double a = sc.nextDouble();

        System.out.println("Insert b: ");
        double b = sc.nextDouble();

        double perimeter = 2 * (a + b);
        double area = a * b;

        System.out.println("Area of the rectangle is " + area + " and the perimeter is " + perimeter + " centimeters.");

    }
}
