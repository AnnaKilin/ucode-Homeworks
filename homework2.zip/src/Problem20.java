import java.util.Scanner;

public class Problem20 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        int n;
        System.out.print("Range of the number: ");
        n = input.nextInt();

        System.out.println("Divided by : 3");
        for (int i = 1; i <= n; i++) {
            if (i % 3 == 0) System.out.print(i + ", ");
        }
        System.out.println("\nDivided by : 5");
        for (int i = 1; i <= n; i++) {
            if (i % 5 == 0) System.out.print(i + ", ");
        }
        System.out.println("\nDivided by : 3 & 5");
        for (int i = 1; i <= n; i++) {
            if (i % 3 == 0 && i % 5 == 0) System.out.print(i + ", ");
        }

    }

}

