package basket;

public class student {
    private String  Name;
    private int Height;

    public student(String name, int Height) {
        this.Name = name;
        this.Height = Height;
    }

    public int getHeight() {
        return Height;
    }

    public String getName(){
        return Name;
    }
}


